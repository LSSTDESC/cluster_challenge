#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_3.tar.gz 3083 3084 3085 3086 3256 3257 3258 3259 3260 3261 3262 3263 3264 3265 3266 3267 3268 3441
