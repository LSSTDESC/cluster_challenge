#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_6.tar.gz 9050 9169 9170 9171 9172 9173 9174 9175 9176 9177 9178 9298 9299 
