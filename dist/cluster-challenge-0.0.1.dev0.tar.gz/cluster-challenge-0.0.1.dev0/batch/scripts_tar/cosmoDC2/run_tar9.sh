#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_9.tar.gz 9683 9684 9685 9686 9687 9688 9689 9690 9810 9811 9812 9813 9814 9815 9816
