#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_7.tar.gz 9300 9301 9302 9303 9304 9305 9306 9425 9426 9427 9428 9429 9430 9431 
