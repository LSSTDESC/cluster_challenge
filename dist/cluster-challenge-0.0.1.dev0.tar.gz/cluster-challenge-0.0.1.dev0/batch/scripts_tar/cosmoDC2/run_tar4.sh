#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_4.tar.gz 8786 8787 8788 8789 8790 8791 8792 8793 8794 8913 8914 8915 8916 8917 
