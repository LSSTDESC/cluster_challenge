#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_3.tar.gz 10326 10327 10328 10329 10444 10445 10446 10447 10448 10449 10450 10451 10452
