#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_5.tar.gz 8918 8919 8920 8921 9042 9043 9044 9045 9046 9047 9048 9049 
