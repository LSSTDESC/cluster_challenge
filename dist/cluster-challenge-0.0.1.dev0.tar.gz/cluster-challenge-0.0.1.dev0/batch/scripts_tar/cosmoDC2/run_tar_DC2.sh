#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_small_photoz_flexzboost/v0/
tar -czvf DC2_photoz_v0.tar.gz 4230 4229 4029 4028 4027 3831 3830
