#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_1.tar.gz 10066 10067 10068 10069 10070 10071 10072 10073 10074 10193 10194 10195
