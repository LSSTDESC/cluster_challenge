#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_8.tar.gz 9432 9433 9434 9554 9555 9556 9557 9558 9559 9560 9561 9562 9681 9682
