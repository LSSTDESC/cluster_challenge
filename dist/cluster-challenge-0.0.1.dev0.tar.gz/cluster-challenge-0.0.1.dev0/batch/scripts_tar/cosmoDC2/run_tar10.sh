#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_10.tar.gz 9817 9818 9937 9938 9939 9940 9941 9942 9943 9944 9945 9946
