#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/cosmoDC2_photoz_flexzboost/v1
tar -czvf cosmoDC2_photoz_v1_2.tar.gz 10196 10197 10198 10199 10200 10201 10202 10321 10322 10323 10324 10325
