#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_8.tar.gz 4434 4435 4436 4437 4438 4439 4440 4441 4636 4637 4638 4639 4640 4641 4642 4643 4644 4645
