#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_7.tar.gz 4225 4226 4227 4228 4229 4230 4231 4232 4233 4234 4235 4236 4428 4429 4430 4431 4432 4433
