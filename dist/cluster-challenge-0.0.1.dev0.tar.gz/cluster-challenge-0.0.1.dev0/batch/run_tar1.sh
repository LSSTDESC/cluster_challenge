#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_1.tar.gz 2723 2724 2725 2726 2727 2728 2729 2730 2731 2732 2733 2734 2735 2896 2897 2898 2899 2900
