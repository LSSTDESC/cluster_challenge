#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_6.tar.gz 3835 3836 3837 4022 4023 4024 4025 4026 4027 4028 4029 4030 4031 4032 4033 4034 4035 4224
