#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_2.tar.gz 2901 2902 2903 2904 2905 2906 2907 2908 2909 3074 3075 3076 3077 3078 3079 3080 3081 3082
