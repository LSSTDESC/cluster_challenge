#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_9.tar.gz 4646 4647 4648 4848 4849 4850 4851 4852 4853 4854 4855 4856 4857 4858 4859 4860 5062 5063 
