#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_4.tar.gz 3442 3443 3444 3445 3446 3447 3448 3449 3450 3451 3452 3453 3454 3631 3632 3633 3634 3635 
