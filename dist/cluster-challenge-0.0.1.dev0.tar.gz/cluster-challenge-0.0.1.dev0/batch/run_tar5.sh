#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_5.tar.gz 3636 3637 3638 3639 3640 3641 3642 3643 3825 3826 3827 3828 3829 3830 3831 3832 3833 3834
