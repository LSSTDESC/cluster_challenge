#!/usr/bin/zsh
cd /sps/lsst/users/tguillem/web/clusters/catalogs/DC2_photoz_flexzboost/v0/
tar -czvf DC2_photoz_flexzboost_v0_10.tar.gz 5064 5065 5066 5067 5068 5069 5070 5071 5072 5073 5074
