from setuptools import setup

def local_scheme(version):
    return ''

setup(setup_requires=['setuptools_scm'], use_scm_version={"local_scheme": local_scheme})

